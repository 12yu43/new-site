import React from 'react'
import DisplayInfo from '../_components/DisplayInfo'

const AdvertisePage = () => {
  return (
    <> <DisplayInfo pageTitle='advertise' /></>
  )
}

export default AdvertisePage