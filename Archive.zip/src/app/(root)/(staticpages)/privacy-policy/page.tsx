import React from 'react'
import DisplayInfo from '../_components/DisplayInfo'

const PrivacyPolicyPage = () => {
  return (
    <DisplayInfo pageTitle='privacy-policy' />
  )
}

export default PrivacyPolicyPage