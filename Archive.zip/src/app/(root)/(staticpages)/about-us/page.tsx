import React from 'react'
import DisplayInfo from '../_components/DisplayInfo'

const page = () => {
  return (
    <> <DisplayInfo pageTitle='about' /></>
  )
}

export default page