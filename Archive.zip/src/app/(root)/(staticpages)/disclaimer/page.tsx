import React from 'react'
import DisplayInfo from '../_components/DisplayInfo'

const DisclaimerPage = () => {
    return (
        <DisplayInfo pageTitle='disclaimer' />
    )
}

export default DisclaimerPage