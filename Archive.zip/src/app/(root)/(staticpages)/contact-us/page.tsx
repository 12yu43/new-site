import React from 'react'
import DisplayInfo from '../_components/DisplayInfo'

const ContactUsPage = () => {
    return (
        <> <DisplayInfo pageTitle='contact-us' /></>
    )
}

export default ContactUsPage