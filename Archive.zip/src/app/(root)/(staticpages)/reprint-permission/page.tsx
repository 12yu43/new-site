import React from 'react'
import DisplayInfo from '../_components/DisplayInfo'

const ReprintPermissionPage = () => {
  return (
    <DisplayInfo pageTitle='reprint-permission' />
  )
}

export default ReprintPermissionPage