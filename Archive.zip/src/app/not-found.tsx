import { redirect } from 'next/navigation'

const NotFound = () => {
    redirect('/')
}

export default NotFound